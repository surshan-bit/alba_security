#!/usr/bin/env node
// Merges externally-researched Fundamental Analysis batch JSON files into the dashboard.
//
// Usage:
//   node merge-fundamentals.js batch1.json batch2.json ...
//
// Each batch file must be an array of records shaped like:
//   { symbol, fundamentals: { factors: [{key,name,weight,score,metrics,note}, ...] },
//     globalFactors, valuation? }
// (this is the exact shape a research subagent following the 6-factor rubric should return).
//
// What it does:
//   - Recomputes score + verdict independently from the factor-sum (NEVER trusts an agent's
//     self-reported verdict field — a past run found a mismatch this way).
//   - Refuses to overwrite a stock that isn't currently verdict:'pending' (guards against
//     clobbering real data if a batch file is re-merged by mistake).
//   - Derives the legacy `pillars` block (only pillars.val is functionally used, by the
//     technical valuation blend — never delete it even though it's not displayed).
//   - Recomputes Technical via the full valuation-blended classify(), now that pillars.val
//     exists — unless the stock's technical.bucket is already 'insufficient_data', which is
//     left untouched (no CSV history to recompute from).
//
// Output: writes ./stock_dashboard_staged.html next to this script.

const fs = require('fs');
const path = require('path');
const S = require('./lib/scoring');

const DASHBOARD_PATH = process.env.DASHBOARD_PATH || '/home/claude/outputs/stock_dashboard.html';
const CSV_BY_SYMBOL_PATH = process.env.CSV_BY_SYMBOL_JSON; // optional: needed only to recompute Technical for newly-fundamental'd stocks
const batchFiles = process.argv.slice(2);
if (batchFiles.length === 0) {
  console.error('Usage: node merge-fundamentals.js batch1.json batch2.json ...');
  process.exit(1);
}

const TODAY_DISPLAY = new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
const html = fs.readFileSync(DASHBOARD_PATH, 'utf8');
const stocks = S.loadStocks(html);
const csv = CSV_BY_SYMBOL_PATH ? JSON.parse(fs.readFileSync(CSV_BY_SYMBOL_PATH, 'utf8')) : null;

let researched = [];
for (const f of batchFiles) researched = researched.concat(JSON.parse(fs.readFileSync(f, 'utf8')));
console.log('Total researched records to merge:', researched.length);

let merged = 0, notFound = [], skippedNotPending = [], upgradedTechnical = 0, keptInsufficient = 0, noCsvForTechnical = 0;

for (const rec of researched) {
  const stock = stocks.find(s => S.tickerSymbol(s.ticker) === rec.symbol.toUpperCase());
  if (!stock) { notFound.push(rec.symbol); continue; }
  if (stock.verdict !== 'pending') { skippedNotPending.push(rec.symbol); continue; }

  const factors = rec.fundamentals.factors;
  const total = +(factors.reduce((a, f) => a + f.score, 0).toFixed(2));
  const verdict = S.verdictFromTotal(total);

  stock.score = total;
  stock.verdict = verdict;
  stock.fundamentals = { total: 10, factors };
  stock.globalFactors = rec.globalFactors;
  if ((verdict === 'buy' || verdict === 'mbuy') && rec.valuation) stock.valuation = rec.valuation;

  const finF = factors.find(f => f.key === 'fin');
  const profitF = factors.find(f => f.key === 'profit');
  const valF = factors.find(f => f.key === 'val');
  const moatF = factors.find(f => f.key === 'moat');
  const pillarVal = Math.round((valF.score / valF.weight) * 10);
  stock.pillars = {
    fin: Math.round((finF.score / finF.weight) * 10),
    earn: Math.round((profitF.score / profitF.weight) * 10),
    val: pillarVal,
    moat: Math.round((moatF.score / moatF.weight) * 10),
    tech: 5 // placeholder; overwritten below once technical is recomputed
  };

  if (stock.technical && stock.technical.bucket !== 'insufficient_data' && csv) {
    const sym = rec.symbol.toUpperCase();
    const d = csv[sym];
    if (!d) { noCsvForTechnical++; continue; }
    // Shared with refresh-technical.js — see lib/scoring.js.
    const { monthMacdL, monthMacdS, weekMacdL, weekMacdS, monthRsi, weekRsi, weekPctChange, monthPctChange } = S.parseTechnicalFields(d);

    const monthMacdState = S.macdState(monthMacdL, monthMacdS);
    const weekMacdState = S.macdState(weekMacdL, weekMacdS);
    const monthRsiZone = S.rsiZone(monthRsi), weekRsiZone = S.rsiZone(weekRsi);
    const score = +(S.macdPoints(monthMacdState, 2.5) + S.macdPoints(weekMacdState, 1.5) + S.rsiPoints(monthRsiZone) + S.rsiPoints(weekRsiZone) + S.valPoints(pillarVal)).toFixed(2);
    const bucket = S.applyGates(S.bandFromScore(score), { monthMacdState, weekMacdState, monthRsi, weekRsi, weekPctChange, monthPctChange });
    const reason = S.buildReason(bucket, monthMacdState, weekMacdState, monthRsiZone, weekRsiZone, monthRsi, weekRsi, pillarVal);

    stock.technical = {
      bucket, bucketLabel: S.bucketLabels[bucket], score, reason,
      states: {
        monthMacd: monthMacdState, weekMacd: weekMacdState, monthRsi: monthRsiZone, weekRsi: weekRsiZone,
        valuation: pillarVal >= 8 ? 'attractive' : pillarVal >= 6 ? 'reasonable' : pillarVal >= 4 ? 'full' : 'expensive'
      },
      raw: {
        monthMacdLevel: +monthMacdL.toFixed(2), monthMacdSignal: +monthMacdS.toFixed(2),
        weekMacdLevel: +weekMacdL.toFixed(2), weekMacdSignal: +weekMacdS.toFixed(2),
        weekPctChange: +weekPctChange.toFixed(2), monthPctChange: +monthPctChange.toFixed(2),
        monthRsi: +monthRsi.toFixed(2), weekRsi: +weekRsi.toFixed(2), valuationScore: pillarVal
      },
      asof: TODAY_DISPLAY
    };
    stock.pillars.tech = Math.round(score);
    upgradedTechnical++;
  } else if (stock.technical && stock.technical.bucket === 'insufficient_data') {
    keptInsufficient++;
  }

  merged++;
}

console.log('Merged:', merged, '| Not found:', notFound.length, notFound.join(', '));
console.log('Skipped (not pending, would have clobbered real data):', skippedNotPending.length, skippedNotPending.join(', '));
console.log('Technical upgraded to full valuation-blended classify():', upgradedTechnical);
console.log('Kept as insufficient_data (technical untouched):', keptInsufficient);
if (noCsvForTechnical) console.log('No CSV row available to recompute Technical for:', noCsvForTechnical, 'stocks (pass CSV_BY_SYMBOL_JSON env var pointing at a csv_by_symbol.json to enable this).');

const outPath = path.join(__dirname, 'stock_dashboard_staged.html');
fs.writeFileSync(outPath, S.writeStocks(html, stocks));
console.log(`\nWrote staged copy to ${outPath} (NOT published). Run smoke-test.js against it before publishing.`);
