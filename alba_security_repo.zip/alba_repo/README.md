# Alba Securities - Stock Analyzer

This repo is a **backup/version-history copy** of the Alba Securities stock analysis dashboard and
its maintenance tooling. It is not the live, running product.

**Live dashboard:** https://claude.ai/artifact/VbEn1ocnjxCGFL9Bz9S5Wh
This is the one actually used day to day, updated automatically by scheduled refresh jobs
(Fundamental Score, Technical Score from TradingView, and a TradingView watchlist sync). The copy
in this repo is a point-in-time snapshot of it.

## What's in here

- `dashboard/stock_dashboard.html` — a snapshot of the published dashboard (single self-contained
  HTML file: the app, its styling, and all tracked stocks' data).
- `scripts/` — the Node.js helper scripts used to refresh and merge new data into the dashboard
  (Technical Score recompute from a Growth List CSV, Fundamentals merge from research batches, a
  headless-browser smoke test, and shared scoring logic in `scripts/lib/scoring.js`). See
  `scripts/README.md` for the full pipeline, its workflow, and a log of known issues/decisions
  (including a couple of real bugs caught and fixed along the way — worth reading before changing
  the scoring logic).

## Why a backup

The live dashboard already keeps its own version history on Claude's platform. This repo exists so
the maintenance scripts and the institutional knowledge in `scripts/README.md` aren't only sitting
in a temporary work session — they're durably saved and versioned here too.
