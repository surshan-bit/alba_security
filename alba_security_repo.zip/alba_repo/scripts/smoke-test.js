#!/usr/bin/env node
// Headless-Chromium smoke test for a staged dashboard HTML file, before it gets published.
//
// Usage:
//   node smoke-test.js [path-to-staged.html]     (defaults to ./stock_dashboard_staged.html)
//
// Checks: page loads with zero console/page errors, renderDetail() works for a sample of rows
// (including a pending/technical-only row and an insufficient_data row if present), and all
// three Buy Call computations run without throwing.

const path = require('path');
const { chromium } = require('playwright');

const filePath = path.resolve(process.argv[2] || path.join(__dirname, 'stock_dashboard_staged.html'));

(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  const page = await browser.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push('PAGE ERROR: ' + e.message));
  page.on('console', msg => { if (msg.type() === 'error') errors.push('CONSOLE ERROR: ' + msg.text()); });

  await page.goto('file://' + filePath);
  await page.waitForTimeout(1000);

  const result = await page.evaluate(() => {
    const out = {};
    out.totalStocks = stocks.length;
    out.verdictCounts = stocks.reduce((acc, s) => { acc[s.verdict] = (acc[s.verdict] || 0) + 1; return acc; }, {});
    out.bucketCounts = stocks.reduce((acc, s) => { const b = s.technical ? s.technical.bucket : 'none'; acc[b] = (acc[b] || 0) + 1; return acc; }, {});

    const idxPending = stocks.findIndex(s => s.verdict === 'pending');
    const idxInsuff = stocks.findIndex(s => s.technical && s.technical.bucket === 'insufficient_data');
    const idxNormal = stocks.findIndex(s => s.verdict !== 'pending' && s.technical && s.technical.bucket !== 'insufficient_data');
    [idxPending, idxInsuff, idxNormal].forEach(idx => {
      if (idx >= 0) { try { renderDetail(idx); } catch (e) { out['renderDetailErr_' + idx] = e.message; } }
    });

    try { out.buyCalls = computeBuyCalls().length; } catch (e) { out.buyCallsErr = e.message; }
    try { out.momentum = computeMomentumLeaders().length; } catch (e) { out.momentumErr = e.message; }
    try { out.valueWatch = computeValueWatchlist().length; } catch (e) { out.valueWatchErr = e.message; }
    return out;
  });

  console.log(JSON.stringify(result, null, 2));
  console.log('PAGE/CONSOLE ERRORS:', errors.length ? errors : 'none');
  await browser.close();
  process.exit(errors.length ? 1 : 0);
})();
