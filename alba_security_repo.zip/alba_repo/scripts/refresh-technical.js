#!/usr/bin/env node
// Weekly Technical Signal refresh from a new Growth List CSV export.
//
// Usage:
//   node refresh-technical.js <path-to-growth-list.csv>
//
// What it does (mirrors the "weekly-growth-list-refresh" skill, step 3 + step 6's technical part):
//   1. Parses the CSV, matches every dashboard ticker against it by symbol.
//   2. Existing + found in CSV  -> recomputes Technical Signal via the full valuation-blended
//      classify() (uses the stock's existing pillars.val; never touches Fundamentals/Valuation).
//   3. Existing + missing from CSV -> marks technical.bucket = 'insufficient_data', freezes
//      everything else (never deletes a ticker).
//   4. Brand-new symbol in CSV, not yet in the dashboard -> onboards it Technical-only
//      (bandFromScoreTechOnly, no valuation blend) with verdict 'pending' until a Fundamentals
//      pass researches it.
//
// Output: writes ./stock_dashboard_staged.html next to this script. Nothing is published
// automatically — inspect + smoke-test the staged file, then publish it yourself via the
// Artifact tool (diff against the live version first).

const fs = require('fs');
const path = require('path');
const S = require('./lib/scoring');

const DASHBOARD_PATH = process.env.DASHBOARD_PATH || '/home/claude/outputs/stock_dashboard.html';
const csvArg = process.argv[2];
if (!csvArg) {
  console.error('Usage: node refresh-technical.js <path-to-growth-list.csv>');
  process.exit(1);
}
const TODAY_ISO = new Date().toISOString().slice(0, 10);
const TODAY_DISPLAY = new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });

const html = fs.readFileSync(DASHBOARD_PATH, 'utf8');
const stocks = S.loadStocks(html);

const rows = S.parseCSV(fs.readFileSync(csvArg, 'utf8'));
const header = rows[0];
const dataRows = rows.slice(1);
const csvBySymbol = {};
for (const r of dataRows) {
  const obj = {};
  header.forEach((h, i) => (obj[h] = r[i]));
  csvBySymbol[(obj['Symbol'] || '').trim().toUpperCase()] = obj;
}
console.log(`CSV: ${dataRows.length} rows, ${Object.keys(csvBySymbol).length} unique symbols.`);

const dashboardSymbols = new Set(stocks.map(s => S.tickerSymbol(s.ticker)));
const csvSymbols = new Set(Object.keys(csvBySymbol));
const missingFromCsv = [...dashboardSymbols].filter(s => !csvSymbols.has(s));
const newInCsv = [...csvSymbols].filter(s => !dashboardSymbols.has(s));
const missingSet = new Set(missingFromCsv);

// Shared with merge-fundamentals.js — see lib/scoring.js.
const fieldSet = S.parseTechnicalFields;
const hasCompleteHistory = S.hasCompleteTechnicalHistory;

let markedInsufficient = 0, recomputed = 0, fallback = 0;

for (const s of stocks) {
  const sym = S.tickerSymbol(s.ticker);

  if (missingSet.has(sym)) {
    s.technical = {
      bucket: 'insufficient_data',
      bucketLabel: S.bucketLabels.insufficient_data,
      score: null,
      reason: `This ticker was not found in the latest Growth List export (${TODAY_DISPLAY}). Technical Signal is paused until it reappears in a future export; Fundamentals, Valuation and Global Factors remain as last recorded.`,
      states: s.technical ? s.technical.states : undefined,
      raw: s.technical ? s.technical.raw : undefined,
      asof: s.technical ? s.technical.asof : undefined
    };
    markedInsufficient++;
    continue;
  }

  const d = csvBySymbol[sym];
  const f = fieldSet(d);
  if (!hasCompleteHistory(f)) {
    // Legitimate data-availability gap (recently-listed stock etc.) — leave as insufficient_data.
    s.technical = {
      bucket: 'insufficient_data',
      bucketLabel: S.bucketLabels.insufficient_data,
      score: null,
      reason: 'Monthly MACD/RSI history is not yet available for this ticker in the Growth List export (common for recently-listed stocks). Technical Signal will populate once enough price history accrues.',
      states: undefined, raw: undefined, asof: undefined
    };
    fallback++;
    continue;
  }

  const monthMacdState = S.macdState(f.monthMacdL, f.monthMacdS);
  const weekMacdState = S.macdState(f.weekMacdL, f.weekMacdS);
  const monthRsiZone = S.rsiZone(f.monthRsi), weekRsiZone = S.rsiZone(f.weekRsi);
  const hasFundamentals = s.verdict !== 'pending' && s.pillars && typeof s.pillars.val === 'number';
  const pillarVal = hasFundamentals ? s.pillars.val : null;

  const pMonthMacd = S.macdPoints(monthMacdState, 2.5);
  const pWeekMacd = S.macdPoints(weekMacdState, 1.5);
  const pMonthRsi = S.rsiPoints(monthRsiZone);
  const pWeekRsi = S.rsiPoints(weekRsiZone);

  let score, bucket, reason;
  if (hasFundamentals) {
    const pVal = S.valPoints(pillarVal);
    score = +(pMonthMacd + pWeekMacd + pMonthRsi + pWeekRsi + pVal).toFixed(2);
    bucket = S.applyGates(S.bandFromScore(score), { monthMacdState, weekMacdState, monthRsi: f.monthRsi, weekRsi: f.weekRsi, weekPctChange: f.weekPctChange, monthPctChange: f.monthPctChange });
    reason = S.buildReason(bucket, monthMacdState, weekMacdState, monthRsiZone, weekRsiZone, f.monthRsi, f.weekRsi, pillarVal);
  } else {
    score = +(pMonthMacd + pWeekMacd + pMonthRsi + pWeekRsi).toFixed(2);
    bucket = S.applyGates(S.bandFromScoreTechOnly(score), { monthMacdState, weekMacdState, monthRsi: f.monthRsi, weekRsi: f.weekRsi, weekPctChange: f.weekPctChange, monthPctChange: f.monthPctChange });
    reason = S.buildReasonTechOnly(bucket, monthMacdState, weekMacdState, monthRsiZone, weekRsiZone, f.monthRsi, f.weekRsi);
  }

  s.technical = {
    bucket, bucketLabel: S.bucketLabels[bucket], score, reason,
    states: {
      monthMacd: monthMacdState, weekMacd: weekMacdState,
      monthRsi: monthRsiZone, weekRsi: weekRsiZone,
      valuation: pillarVal == null ? undefined : (pillarVal >= 8 ? 'attractive' : pillarVal >= 6 ? 'reasonable' : pillarVal >= 4 ? 'full' : 'expensive')
    },
    raw: {
      monthMacdLevel: +f.monthMacdL.toFixed(2), monthMacdSignal: +f.monthMacdS.toFixed(2),
      weekMacdLevel: +f.weekMacdL.toFixed(2), weekMacdSignal: +f.weekMacdS.toFixed(2),
      weekPctChange: +f.weekPctChange.toFixed(2), monthPctChange: +f.monthPctChange.toFixed(2),
      monthRsi: +f.monthRsi.toFixed(2), weekRsi: +f.weekRsi.toFixed(2),
      valuationScore: pillarVal == null ? undefined : pillarVal
    },
    asof: TODAY_DISPLAY
  };
  recomputed++;
}

// Onboard brand-new tickers (Technical-only, verdict 'pending').
const newStocks = [];
for (const sym of newInCsv) {
  const d = csvBySymbol[sym];
  const f = fieldSet(d);
  if (!hasCompleteHistory(f)) continue; // not enough history yet — skip onboarding until it is available

  const monthMacdState = S.macdState(f.monthMacdL, f.monthMacdS);
  const weekMacdState = S.macdState(f.weekMacdL, f.weekMacdS);
  const monthRsiZone = S.rsiZone(f.monthRsi), weekRsiZone = S.rsiZone(f.weekRsi);
  const score = +(S.macdPoints(monthMacdState, 2.5) + S.macdPoints(weekMacdState, 1.5) + S.rsiPoints(monthRsiZone) + S.rsiPoints(weekRsiZone)).toFixed(2);
  const bucket = S.applyGates(S.bandFromScoreTechOnly(score), { monthMacdState, weekMacdState, monthRsi: f.monthRsi, weekRsi: f.weekRsi, weekPctChange: f.weekPctChange, monthPctChange: f.monthPctChange });
  const reason = S.buildReasonTechOnly(bucket, monthMacdState, weekMacdState, monthRsiZone, weekRsiZone, f.monthRsi, f.weekRsi);

  newStocks.push({
    name: S.cleanName(d['Description'] || sym),
    ticker: `${sym} · ${d['Sector'] || 'Unclassified'}`,
    score: null,
    verdict: 'pending',
    pillars: undefined,
    asof: TODAY_DISPLAY,
    technical: {
      bucket, bucketLabel: S.bucketLabels[bucket], score, reason,
      states: { monthMacd: monthMacdState, weekMacd: weekMacdState, monthRsi: monthRsiZone, weekRsi: weekRsiZone },
      raw: {
        monthMacdLevel: +f.monthMacdL.toFixed(2), monthMacdSignal: +f.monthMacdS.toFixed(2),
        weekMacdLevel: +f.weekMacdL.toFixed(2), weekMacdSignal: +f.weekMacdS.toFixed(2),
        weekPctChange: +f.weekPctChange.toFixed(2), monthPctChange: +f.monthPctChange.toFixed(2),
        monthRsi: +f.monthRsi.toFixed(2), weekRsi: +f.weekRsi.toFixed(2)
      },
      asof: TODAY_DISPLAY
    }
  });
}

console.log(`Recomputed (full/tech-only): ${recomputed} | Marked insufficient_data (missing from CSV): ${markedInsufficient} | Marked insufficient_data (no history yet): ${fallback}`);
console.log(`New tickers onboarded technical-only: ${newStocks.length} / ${newInCsv.length} candidates`);
if (newInCsv.length > newStocks.length) {
  console.log('  (skipped, insufficient history):', newInCsv.filter(sym => !newStocks.some(ns => ns.ticker.startsWith(sym + ' ·'))).join(', '));
}

const allStocks = stocks.concat(newStocks);
const outPath = path.join(__dirname, 'stock_dashboard_staged.html');
fs.writeFileSync(outPath, S.writeStocks(html, allStocks));
console.log(`\nWrote staged copy to ${outPath} (NOT published). Run smoke-test.js against it before publishing.`);
