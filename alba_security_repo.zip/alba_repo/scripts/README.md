# Alba Securities Stock Analyzer — maintenance scripts

Permanent, deduplicated home for the scripts that maintain `/home/claude/outputs/stock_dashboard.html`
(the live dashboard, published at the "Alba Securities - Stock Analyzer" artifact). These replace the
one-off, copy-pasted versions of the same logic that used to be scattered across per-session `/tmp`
scratch folders — every refresh script previously re-pasted its own copy of the MACD/RSI/valuation
scoring rules, which risked the copies silently drifting apart.

## Layout

```
scripts/
  lib/scoring.js        Shared scoring/classification logic + safe stocks-array read/write helpers.
  refresh-technical.js  Weekly cadence: recompute Technical Signal from a new Growth List CSV export.
  merge-fundamentals.js Merge researched Fundamental Analysis batch JSON files (from subagents) in.
  smoke-test.js         Headless-Chromium validation of a staged HTML file before publishing.
```

## Workflow (matches the weekly-growth-list-refresh skill)

1. **Technical refresh (every week, every stock, zero external research calls):**
   ```
   node refresh-technical.js /path/to/growth_list.csv
   ```
   Writes `./stock_dashboard_staged.html`. Existing tickers get their Technical Signal recomputed;
   tickers missing from the CSV are marked `insufficient_data` (never deleted); brand-new tickers in
   the CSV are onboarded Technical-only with `verdict:'pending'`.

2. **Fundamentals merge (only for triggered/new tickers, after subagent research):**
   ```
   CSV_BY_SYMBOL_JSON=./csv_by_symbol.json node merge-fundamentals.js batch1.json batch2.json ...
   ```
   Each batch JSON is an array of `{symbol, fundamentals:{factors}, globalFactors, valuation?}`
   records. The script recomputes score/verdict from the factor sum itself (never trusts an agent's
   self-reported verdict — this caught a real mismatch once), refuses to touch a stock that isn't
   `verdict:'pending'`, and re-derives the legacy `pillars` block Technical scoring depends on.

3. **Validate before publishing, always:**
   ```
   node smoke-test.js ./stock_dashboard_staged.html
   ```
   Exits non-zero on any page/console error. Also spot-checks `renderDetail()` and all three Buy
   Call computations (`computeBuyCalls`, `computeMomentumLeaders`, `computeValueWatchlist`).

4. **Diff, then publish** the staged file over the live dashboard via the Artifact tool — read the
   live version first, diff it against the staged file to confirm only the intended changes are
   present, then publish (`force: true` if the tool reports a newer-version conflict, which is
   expected since staging happens outside the Artifact tool's own version tracking).

## Key invariants these scripts protect

- **Never delete a ticker.** A stock dropped from the CSV export is marked `technical.bucket =
  'insufficient_data'`; Fundamentals/Valuation/Global Factors stay frozen as last recorded.
- **Never touch `pillars.val`** except when a fresh Fundamentals merge legitimately recomputes it —
  it's dormant in the UI but the Technical scoring pipeline's valuation blend depends on it.
- **Never trust an agent's self-reported verdict** — always recompute `score`/`verdict` from the
  6-factor sum independently (`verdictFromTotal` in `lib/scoring.js`).
- **`lib/writeStocks()` uses a replacer *function*, not a plain string**, when swapping the `stocks`
  array back into the HTML. This was a real bug found while building this cleanup: a plain-string
  replacement lets stray `$&`/`$1`/etc. sequences inside stock data (e.g. a note mentioning
  "$158M") trigger `String.replace`'s special substitution patterns and silently splice in
  unrelated parts of the file. Always go through `lib/scoring.js`'s `loadStocks`/`writeStocks`
  rather than hand-rolling a regex replace.
- **`writeStocks` refuses to run unless the stocks block appears exactly once** in the HTML, guarding
  against a corrupted regex match silently overwriting the wrong content.

## Validated against the live dashboard (2026-09-23)

- `loadStocks` → `writeStocks` → `loadStocks` round-trips byte-for-byte (509 stocks, verified).
- The scoring logic in `lib/scoring.js` reproduces the live dashboard's stored Technical bucket for
  399/399 checkable stocks and stored Fundamentals verdict for 502/502 stocks (2 stocks showed a
  small pre-existing score drift of <1 point with no bucket change — likely `pillars.val` updated
  after their last Technical recompute; harmless staleness, not a scoring bug).

## Tried and rejected: mechanizing Fundamental Analysis from TradingView (2026-09-23)

Investigated whether TradingView's MCP tools (`get_symbol_data_batch`, `get_forecasts`) could
replace some of the manual research in the 6-factor Fundamental Analysis, to cut WebSearch/WebFetch
load as the tracked list grows. Batch-fetched real data for all 509 tracked tickers first, rather
than assuming from a small sample. Findings, for the record:

- **Profitability & Capital Efficiency (ROE, ROCE/ROIC)**: `return_on_equity_ttm` and
  `return_on_invested_capital_ttm` came back **null for all 509 stocks** in this universe. Not
  usable at all.
- **Growth & Cash Flow (YoY growth, FCF)**: `earnings_per_share_diluted_YoYTTM`,
  `total_revenue_YoYTTM` null for ~100% of stocks; `free_cash_flow_ttm` populated for only
  ~1–2%. Not usable at all.
- **Financial Health (D/E, current ratio, working capital)**: `debt_to_equity_fq` /
  `current_ratio_fq` populated for only ~5% of stocks (mostly large caps/banks/IT majors) —
  `total_debt_to_ebitda_fy` and `cash_n_short_term_invest_to_total_debt_fy` are well covered
  (~95%) but only capture leverage, not the full factor.
- **Valuation (P/E, P/B relative to return profile)**: P/E, P/B, and PEG
  (`price_earnings_growth_ttm`) are well covered (~90–99%), so this looked mechanizable — but a
  calibration run against 48 already-researched stocks gave a mean absolute error of 0.63 points
  on the 1.5-point scale (only 35% within 0.3 pts of the human-researched score). A low PEG does
  not reliably mean "cheap" for this stock set — e.g. DIACABS has a PEG of 0.08 but a manually
  researched Valuation score of only 0.1/1.5, because it has **negative book value** (P/B of ‑33),
  which a plain PEG/P-E/P-B bucket formula never checks for.

Conclusion: this stock universe (mostly Indian small/mid-caps) just isn't well covered by
TradingView's fundamentals fields the way large-caps are — the 3-stock spot check that started
this investigation (which happened to include TCS) was not representative. Decided not to pursue
mechanical scoring for any factor; Fundamental Analysis stays fully manual/subagent-researched as
before. If this is revisited, don't restart from scratch — the coverage numbers above and the
DIACABS-style failure mode are the first things to check again.

## Also tried and rejected: screener-mcp / other data-API alternatives (2026-09-23)

Investigated `screener-mcp` (github.com/LogeshR15/screener-mcp), a community MCP that scrapes
screener.in for `get_financials`, `get_company_overview`, `get_shareholding_pattern`, etc. — a
structurally much better fit than TradingView, since it's the same site we already source
Fundamentals from manually, so coverage for this small/mid-cap universe should be fine. Not
pursued, for reasons that have nothing to do with data coverage:

- It's not an official API — screener.in has none (confirmed on their own Premium page: the
  paid tier only adds Excel/CSV export, no REST/GraphQL endpoint). The MCP is unofficial scraping
  using a personal screener.in login (`SCREENER_USERNAME`/`SCREENER_PASSWORD` env vars) — running
  that against 500+ stocks on a schedule risks the account being rate-limited or suspended.
- It's a local `uvx`-installed stdio MCP server (`claude mcp add screener -s user -- uvx
  screener-mcp`), not a claude.ai connector (checked the registry — not listed) and not
  something the cloud sessions behind the scheduled tasks (weekend deep-refresh, etc.) can reach
  or authenticate to. There's no path to wire it into the existing automation from here.

Also checked whether a *sanctioned* replacement exists for the current screener.in-via-subagent
research step:

- General global fundamentals APIs (EODHD, Financial Modeling Prep) advertise broad ratio
  coverage but only claim "Major US, UK, EU, and Asian exchanges" for India, with no confirmed
  NSE/BSE small/mid-cap depth in their docs — the same shape of gap that made TradingView
  unusable, untested but likely to repeat.
- Real India-specific institutional data vendors exist (Global Datafeeds, Trendlyne, Tickertape,
  StockEdge) but are enterprise sales products with no public API pricing/docs and no self-serve
  connector — not something obtainable or wireable from within a session.

Conclusion: no sanctioned, connectable alternative currently exists to reduce the WebSearch/
WebFetch load of the weekend Fundamentals refresh. The manual/subagent-researched approach
stays as-is. If revisited, the open door is a real commercial relationship with an India-specific
data vendor (a business decision, not a technical one) — not another community MCP or general
global data API, both of which hit the same walls documented here and above.

## TradingView Watchlist Sync silently drops unresolvable symbols (2026-09-23)

`mcp-watchlist-create-watchlist` (and, less commonly, `mcp-watchlist-add-to-watchlist`) will
silently drop any `EXCHANGE:TICKER` it can't resolve — no error, no partial-failure flag, the
symbol just isn't in the returned `symbols` array. This bit us for real: RESONANCE only trades
on **BSE** (there is no `NSE:RESONANCE`), the sync defaulted it to `NSE:` (the fallback for any
ticker not in the known-exceptions list), and it vanished from the watchlist with the create call
still reporting success. It was only caught because the dashboard owner happened to check by hand.

Known BSE-listed exceptions (append here whenever a new one is discovered — don't rely on the
previous watchlist's contents alone, since a prior silent-drop could mean an exception is
temporarily missing from it): **VIKRAMTH, VALIANT, BEMHY, BRPL, DANLAW, NSDL, OVOBELE,
RESONANCE**. Everything else defaults to `NSE:`.

Because that default is exactly what fails silently, both the scheduled "TradingView Watchlist
Sync" task's prompt and the dashboard's "Refresh Data" manual-trigger message for that job now
require a **mandatory post-create verification**: diff the symbols the create call actually
returned against the intended list, look up any missing ticker's real exchange via
`mcp-tv-search-symbols`, retry with `mcp-watchlist-add-to-watchlist`, and verify again with
`mcp-watchlist-get-watchlist`. Anything still unresolved after that gets recorded in a
`droppedTickers` array on the `watchlistSyncLog` run record (status `partial` instead of
`completed`) — the dashboard's Data Refresh page renders that array in red so it's impossible to
miss. If you're writing or reviewing any TradingView watchlist sync logic, don't trust a
"success" response from create/add alone — always verify the resulting watchlist.

## TradingView scanner API rate-limits mid-batch on the Technical Score fetch (2026-09-23)

The scheduled "Technical Score refresh" task (2PM/4PM IST weekdays) fetches all ~510 tracked
tickers from `mcp-tv-get-symbol-data-batch` in batches of 50 (~11 batches per run). Firing all 11
batches back-to-back with no delay hit a mid-run TradingView 429 rate limit for real: batches 0-5
came back with "Quote data not found" for every symbol in the batch, including symbols known to be
valid (e.g. `NSE:TCS`). Waited ~10 minutes total (90s, then 180s, then 280s) between retries and
the rate limit was still in effect, so that run finished with only 136/509 stocks refreshed live,
marked `partial` in `techFetchLog`, and left the rest on their CSV/last-known fallback (per the
schedule's own designed behavior — the CSV upload is exactly the intended fallback for this, not a
workaround).

The scheduled task's prompt has since been updated to pace itself instead of firing batches
back-to-back: batches now run strictly one at a time with an 8-second gap between calls, and a
batch that comes back rate-limited (429, or every symbol returning no data) gets retried with
backoff (60s, then 180s) before being given up on and left on fallback. If 3+ consecutive batches
are still rate-limited after backing off, the run stops attempting further live batches entirely
rather than fighting a limit that clearly hasn't lifted, and logs `rateLimitedBatches` + a `note`
field on the `techFetchLog` run record so the "Technical Data Fetch Schedule" panel shows it
happened, instead of it only being visible as an unexplained partial run. If this recurs even with
pacing, the next lever to pull is a longer per-batch delay (try 15-20s) or splitting the run across
both the 2PM and 4PM slots rather than fetching everything in one sitting.

## Not migrated here

Batch research outputs (`fundamentals_batch*.json`), staged HTML snapshots, and per-refresh scratch
data (CSV dumps, match results, logs) are session-specific working data, not reusable code — they're
left in the session scratchpad rather than copied into this permanent folder.
